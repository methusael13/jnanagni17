
var requestAnimationFrame =
    window.requestAnimationFrame || window.webkitRequestAnimationFrame ||
    window.mozRequestAnimationFrame || window.msRequestAnimationFrame ||
    window.oRequestAnimationFrame;

// CallbackList object
function CallbackList() {
    this.cbMap = [];
    this.callbacks = [];
};

CallbackList.prototype = {
    add: function(callback) {
        this.cbMap.push(true);
        this.callbacks.push(callback);

        return this.cbMap.length - 1;
    },

    setIterable: function(idx, itr) { this.cbMap[idx] = itr; },
    getList: function() { return this.callbacks; },

    execList: function(duration) {
        for (var i = this.cbMap.length - 1; i >= 0; i--) {
            if (this.cbMap[i])
                (this.callbacks[i])(duration);
        }
    }
};

var animate = function(key, val, vi, vf, duration, cbRenderFrame, cbProgressEnd) {
    var t0 = 0, progress, elapsed, tprev = 0;
    var step = function(timestamp) {
        elapsed = timestamp - t0;
        // Interpolation calculations here
        progress = elapsed / duration;

        key[val] = vi + progress * (vf - vi);
        if (progress >= 0.9833) {
            t0 = timestamp;
            if (cbProgressEnd) cbProgressEnd();
        }

        if (cbRenderFrame)
            cbRenderFrame(timestamp - tprev, progress);
        if (key['stop'] === undefined || !key['stop'])
            requestAnimationFrame(step);
        tprev = timestamp;
    };

    requestAnimationFrame(step);
};

var loader = null, loaderText, lCtxt;
var cirConfig = new Array(5);
var config = {
    'rad': 0.7, 'drad': 0.1,
    'progress': 0, 'cx': 0, 'cy': 0,
    'stop': false
};

const PI_TWO = 2 * Math.PI;
const PI_OVER_TWO = Math.PI / 2;

var initLoader = function() {
    if (!loader.getContext) return;

    lCtxt = loader.getContext("2d");
    config['cx'] = loader.width / 2; config['cy'] = loader.height / 2;
    loaderText = document.getElementById('loader-text');

    var minav = PI_TWO / 6000.0; maxav = PI_TWO / 2000.0;
    for (var i = 0; i < cirConfig.length; ++i) {
        cirConfig[i] = new Object();
        cirConfig[i]['theta0'] = i * PI_TWO / cirConfig.length;
        cirConfig[i]['angv'] = (maxav - minav) * Math.random() + minav;
        cirConfig[i]['theta'] = cirConfig[i]['theta0'];
    }
};

var stopLoader = function () { config['stop'] = true; };

var loaderRender = function(duration, progress) {
    var cx = config['cx'], cy = config['cy'];
    var rad = config['rad'] * cx, drad = config['drad'] * cx;
    lCtxt.clearRect(0, 0, loader.width, loader.height);

    var cxn, cyn;
    for (var i = 0; i < cirConfig.length; ++i) {
        lCtxt.beginPath();
        lCtxt.lineWidth = 2; lCtxt.globalAlpha = 0.5;
        lCtxt.strokeStyle = '#ffffff';
        lCtxt.shadowBlur = i % 2 == 0 ? 20 : 0;
        lCtxt.shadowColor = lCtxt.strokeStyle;

        cirConfig[i]['theta'] = 
            (cirConfig[i]['theta'] + cirConfig[i]['angv'] * duration) % PI_TWO;
        cxn = cx + drad * Math.cos(cirConfig[i]['theta']);
        cyn = cy + drad * Math.sin(cirConfig[i]['theta']);

        lCtxt.arc(cxn, cyn, rad, 0, PI_TWO, true);
        lCtxt.stroke();
    }
};

const lText = 'Jñānāgni';
var updateLoad = function(duration, progress) {
    var idx0 = parseInt(progress * lText.length);

    var text = '';
    for (var i = 0; i < lText.length; ++i) {
        text += i <= idx0 ? lText.charAt(i) :
                String.fromCharCode(26 * Math.random() + 65);
    }

    loaderText.innerHTML = text;
    loaderRender(duration, progress);
};

function startLoader() {
    initLoader();
    animate(config, 'progress', 0, PI_TWO, 5000, updateLoad);
};

(function monitor() {
    setTimeout(function() {
        loader = document.getElementById("loader");
        if (!loader) monitor();
        else startLoader();
    }, 250);
})();
